import java.util.ArrayList;

public class PaireChaineEntier {

    private String chaine;
    private int entier;

    public PaireChaineEntier(String chaine, int entier){
        this.chaine = chaine ;
        this.entier = entier;
    }

    public String getChaine() {
        return chaine;
    }

    public int getEntier() {
        return entier;
    }

    public void setEntier(int entier) {
        this.entier = entier;
    }

    public void incrementeEntier(int i){
        this.entier = this.entier + i;
    }

    public void decrementeEntier(int i){
        this.entier = this.entier - i;
    }

    public void affichePaire(){
        System.out.println("Mot : "  + this.getChaine());
        System.out.println("Poids:" + this.getEntier());
        System.out.println("");
    }

}
