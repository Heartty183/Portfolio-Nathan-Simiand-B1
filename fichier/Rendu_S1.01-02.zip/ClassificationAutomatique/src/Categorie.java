import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Categorie {

    private String nom; // le nom de la catégorie p.ex : sport, politique,...
    private ArrayList<PaireChaineEntier> lexique; //le lexique de la catégorie

    // constructeur
    public Categorie(String nom) {
        this.nom = nom;
    }


    public String getNom() {
        return nom;
    }


    public  ArrayList<PaireChaineEntier> getLexique() {
        return lexique;
    }


    // initialisation du lexique de la catégorie à partir du contenu d'un fichier texte
    public void initLexique(String nomFichier) {
        this.lexique = new ArrayList<PaireChaineEntier>();
        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                String chaine = ligne.split(":")[0];
                if (chaine == "" ){
                     scanner.nextLine();
                }
                else {
                    int entier = Integer.parseInt(ligne.split(":")[1]);
                    PaireChaineEntier p = new PaireChaineEntier(chaine, entier);
                    this.lexique.add(p);
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //calcul du score d'une dépêche pour la catégorie
    public int score(Depeche d) {
        int comparaison = 0;
        ArrayList<String> liste_mots = d.getMots();
        int i = 0;
        int somme = 0;
        comparaison++;
        while (i < liste_mots.size()){
            somme = somme + UtilitairePaireChaineEntier.entierPourChaine(this.getLexique(), liste_mots.get(i));
            i = i + 1;
            comparaison++;
        }
        String ecriture = String.valueOf(comparaison);
        try {
            FileWriter file = new FileWriter("resultat_comp-scoreDeche");
            file.write(ecriture);
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return somme;
    }

    public static int indexDeCategory(ArrayList<Categorie> vC, String S){
        for(int i = 0; i < vC.size(); i++){
            if (vC.get(i).getNom().compareTo(S) == 0){
                return i;
            }
        }
        return -1;
    }


}
