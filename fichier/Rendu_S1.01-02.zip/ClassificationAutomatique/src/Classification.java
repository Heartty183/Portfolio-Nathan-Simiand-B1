import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Classification {


    private static ArrayList<Depeche> lectureDepeches(String nomFichier) {
        //creation d'un tableau de dépêches
        ArrayList<Depeche> depeches = new ArrayList<>();
        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                String id = ligne.substring(3);
                ligne = scanner.nextLine();
                String date = ligne.substring(3);
                ligne = scanner.nextLine();
                String categorie = ligne.substring(3);
                ligne = scanner.nextLine();
                String lignes = ligne.substring(3);
                while (scanner.hasNextLine() && !ligne.equals("")) {
                    ligne = scanner.nextLine();
                    if (!ligne.equals("")) {
                        lignes = lignes + '\n' + ligne;
                    }
                }
                Depeche uneDepeche = new Depeche(id, date, categorie, lignes);
                depeches.add(uneDepeche);
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return depeches;
    }


    public static void classementDepeches(ArrayList<Depeche> depeches, ArrayList<Categorie> categories, String nomFichier) throws IOException {
        ArrayList<PaireChaineEntier> nbCorrect = new ArrayList<>();
        ArrayList<Integer> nbtot = new ArrayList<>();
        for(int i = 0; i < categories.size(); i++){
            if(nbCorrect.contains(categories.get(i).getNom()) == false){
                nbCorrect.add(new PaireChaineEntier(categories.get(i).getNom(), 0));
                nbtot.add(0);
            }
        }
        String chaine = "";
        for (int i = 0; i < depeches.size(); i++) {
            int index_cat_sup = 0;
            for (int j = 0; j < categories.size(); j++) {
                if (categories.get(index_cat_sup).score(depeches.get(i)) < categories.get(j).score(depeches.get(i))) {
                    index_cat_sup = j;
                }
            }
            chaine = chaine + ("n°" + (i+1) + " => " + categories.get(index_cat_sup).getNom() + "\n");

            nbtot.set(Categorie.indexDeCategory(categories, depeches.get(i).getCategorie()), nbtot.get(Categorie.indexDeCategory(categories, depeches.get(i).getCategorie())) + 1);
            if (depeches.get(i).getCategorie().compareTo(categories.get(index_cat_sup).getNom()) == 0){
                nbCorrect.get(index_cat_sup).setEntier(nbCorrect.get(index_cat_sup).getEntier() + 1);
            }

        }
        float Moyenne = 0;
        int i = 0;
        while(i < nbCorrect.size()){
            chaine = chaine +nbCorrect.get(i).getChaine() +" => "+ (nbCorrect.get(i).getEntier())*100/nbtot.get(i) + "% \n";
            Moyenne = Moyenne + (nbCorrect.get(i).getEntier())*100/nbtot.get(i);
            i++;
        }

        Moyenne = Moyenne/nbtot.size();
        chaine = chaine + "TOTAL : "+Moyenne + "%";

        System.out.println(chaine);
        try {
            FileWriter file = new FileWriter("resultat");
            file.write(chaine);
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public static ArrayList<PaireChaineEntier> initDico(ArrayList<Depeche> depeches, String categorie) {
        ArrayList<PaireChaineEntier> resultat = new ArrayList<>();
        int i = 0;
        while (i < depeches.size()){
            String cat = depeches.get(i).getCategorie();
            if (cat.compareToIgnoreCase(categorie)  == 0 ){
                int y = 1;
                ArrayList<String> mot;
                mot = depeches.get(i).getMots();
                while (y < mot.size()){
                    int x = 0;
                    boolean dedan = false;
                    forebreak:
                    while (x < resultat.size()){
                        if (resultat.get(x).getChaine().compareToIgnoreCase(mot.get(y)) == 0) {
                            dedan = true;
                            break forebreak;
                        }else{
                            dedan = false;
                        }
                        x++;
                    }
                    if(!dedan){
                        resultat.add(new PaireChaineEntier(mot.get(y), 0));
                    }
                    y++;
                }
            }
            i++;
        }
        return resultat;
    }

    public static void calculScores(ArrayList<Depeche> depeches, String categorie, ArrayList<PaireChaineEntier> dictionnaire) {
        int i = 0;
        int comparaison =0;
        ArrayList<PaireChaineEntier> mots = new ArrayList<>();
        comparaison++;
        for(int j = 0; j < dictionnaire.size(); j++){
            PaireChaineEntier p = new PaireChaineEntier(dictionnaire.get(j).getChaine(), 0);
            mots.add(p);
            comparaison++;
        }
        comparaison++;
        while (i < depeches.size()) {
            ArrayList<String> mot;
            mot = depeches.get(i).getMots();
            String cat = depeches.get(i).getCategorie();
            int y = 0;
            while (y < mot.size()) {
                int z = 0;
                while (z < mots.size()) {
                    comparaison++;
                    if (mots.get(z).getChaine().compareToIgnoreCase(mot.get(y)) == 0) {
                        comparaison++;
                        if (cat.compareToIgnoreCase(categorie) == 0){
                            dictionnaire.get(z).incrementeEntier(1);
                        }else{
                            dictionnaire.get(z).decrementeEntier(1);
                        }
                    }
                    comparaison++;
                    z++;
                }
                comparaison++;
                y++;
            }
            comparaison++;
            i++;
        }
        String ecriture = String.valueOf(comparaison);
        try {
            FileWriter file = new FileWriter("resultat_comp-calculescore");
            file.write(ecriture);
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        public static int poidsPourScore(int score){
            if (score < 0){
                return 0;
            }else if (score <= 2) {
                return 1;
            } else if (score <= 8) {
                return 2;
            } else {
                return 3;
            }
        }


    public static void generationLexique(ArrayList<Depeche> depeches, String categorie, String nomFichier) {
        ArrayList<PaireChaineEntier> dico = new ArrayList<>();
        dico = initDico(depeches, categorie);
        calculScores(depeches, categorie, dico);
        for(int i = 0; i < dico.size(); i++){
            dico.get(i).setEntier(poidsPourScore(dico.get(i).getEntier()));
        }
        String chaine = "";
        for (int i = 0; i < dico.size(); i++){
            chaine = chaine + (dico.get(i).getChaine() + ":" + dico.get(i).getEntier() + "\n");
        }
        try {
            FileWriter file = new FileWriter(categorie);
            file.write(chaine);
            file.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) throws IOException {
/*
        //Chargement des dépêches en mémoire
       System.out.println("chargement des dépêches");
        ArrayList<Depeche> depeches = lectureDepeches("./depeches.txt");

      // for (int i = 0; i < depeches.size(); i++) {
      //     depeches.get(i).afficher();
      // }
      // System.out.println(depeches.get(200).getMots());

*/
        long startTimeGeneration = System.currentTimeMillis();
        ArrayList<Depeche> depeches = lectureDepeches("depeches.txt");
        ArrayList<Depeche> test = lectureDepeches("test.txt");

        ArrayList<Categorie> cat = new ArrayList<>();
        Categorie SPORTS = new Categorie("SPORTS");
        Categorie ENVIRONNEMENT_SCIENCES = new Categorie("ENVIRONNEMENT-SCIENCES");
        Categorie ECONOMIE = new Categorie("ECONOMIE");
        Categorie CULTURE = new Categorie("CULTURE");
        Categorie POLITIQUE = new Categorie("POLITIQUE");
        cat.add(SPORTS); cat.add(ENVIRONNEMENT_SCIENCES); cat.add(ECONOMIE); cat.add(CULTURE); cat.add(POLITIQUE);
        for (int i = 0; i < cat.size(); i++){
            generationLexique(depeches, cat.get(i).getNom(), cat.get(i).getNom());
            cat.get(i).initLexique(cat.get(i).getNom());
        }
        long endTimeGeneration = System.currentTimeMillis();

        long StartTimeclasifiquation = System.currentTimeMillis();
        classementDepeches(test, cat, "resultat");
        long endTimeclasiqfiquation = System.currentTimeMillis();
        System.out.println("La Génération des lexique a été réalisée en : " + (endTimeGeneration-startTimeGeneration) + "ms");
        System.out.println("La clasifiquation des lexique a été réalisée en : " + (endTimeclasiqfiquation-StartTimeclasifiquation) + "ms");
    }


}

