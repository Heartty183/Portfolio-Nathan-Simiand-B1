import java.util.ArrayList;

public class UtilitairePaireChaineEntier {


    public static int indicePourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i = 0;
        while ( i < listePaires.size()){
            if (chaine.compareTo(listePaires.get(i).getChaine()) == 0){
                return i;
            }
            i++;
        }
        return -1;
    }

    public static int entierPourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i = 0;
        String pos;
        while (i < listePaires.size()){
            pos = listePaires.get(i).getChaine();
            if (pos.compareTo(chaine) == 0){
                return listePaires.get(i).getEntier();
            }
            i++;
        }
        return 0;
    }


    public static String chaineMax(ArrayList<PaireChaineEntier> listePaires) {
        String fin = null;
        int i = 1;
        int poid = listePaires.get(0).getEntier();
        while (i < listePaires.size()) {
            if (listePaires.get(i).getEntier() >= poid) {
                poid = listePaires.get(i).getEntier();
                fin = listePaires.get(i).getChaine();
            }
        i++;
        }
        return fin;
    }


    public static float moyenne(ArrayList<PaireChaineEntier> listePaires) {
        float moy = 0;
        int i = 0;
        while (i < listePaires.size()){
            moy = moy + listePaires.get(i).getEntier();
            i++;
        }
        if (i == listePaires.size()){
            moy = moy / i;
            return moy;
        }else{
            return -1;
        }
    }

}
